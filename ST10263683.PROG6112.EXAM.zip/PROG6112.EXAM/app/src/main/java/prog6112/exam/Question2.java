package prog6112.exam;

import javax.swing.*;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

// Interface definition
interface IMovieTickets {
    double calculateTotalTicketPrice(int numberOfTickets, double ticketPrice);

    boolean validateData(MovieTicketData movieTicketData);
}

// Data class to hold movie ticket information
class MovieTicketData {
    String movieName;
    int numberOfTickets;
    double ticketPrice;

    public MovieTicketData(String movieName, int numberOfTickets, double ticketPrice) {
        this.movieName = movieName;
        this.numberOfTickets = numberOfTickets;
        this.ticketPrice = ticketPrice;
    }
}

// Implementation of the interface
class MovieTickets implements IMovieTickets {
    private static final double VAT_RATE = 0.14;

    @Override
    public double calculateTotalTicketPrice(int numberOfTickets, double ticketPrice) {
        double total = numberOfTickets * ticketPrice;
        return total + (total * VAT_RATE);
    }

    @Override
    public boolean validateData(MovieTicketData movieTicketData) {
        if (movieTicketData.movieName == null || movieTicketData.movieName.isEmpty()) {
            JOptionPane.showMessageDialog(null, "Movie name cannot be empty.");
            return false;
        }
        if (movieTicketData.numberOfTickets <= 0) {
            JOptionPane.showMessageDialog(null, "Number of tickets must be greater than zero.");
            return false;
        }
        if (movieTicketData.ticketPrice <= 0) {
            JOptionPane.showMessageDialog(null, "Ticket price must be greater than zero.");
            return false;
        }
        return true;
    }

    public Integer TotalMovieSales(int[] sales) {
       
        throw new UnsupportedOperationException("Unimplemented method 'TotalMovieSales'");
    }

    public Object TopMovie(String[] movies, int[] totalSales) {
     
        throw new UnsupportedOperationException("Unimplemented method 'TopMovie'");
    }
}

// Main GUI application
public class Question2 extends JFrame {
    private JComboBox<String> movieComboBox;
    private JTextField ticketPriceField, numberOfTicketsField;
    private JTextArea reportArea;
    private MovieTickets movieTickets = new MovieTickets();

    public Question2() {
        setTitle("Movie Tickets");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        JPanel inputPanel = new JPanel(new GridLayout(3, 2));
        movieComboBox = new JComboBox<>(new String[] { "Napoleon", "Oppenheimer", "Damsel" });
        ticketPriceField = new JTextField();
        numberOfTicketsField = new JTextField();

        inputPanel.add(new JLabel("Movie:"));
        inputPanel.add(movieComboBox);
        inputPanel.add(new JLabel("Number of Tickets:"));
        inputPanel.add(numberOfTicketsField);
        inputPanel.add(new JLabel("Ticket Price:"));
        inputPanel.add(ticketPriceField);

        add(inputPanel, BorderLayout.NORTH);

        reportArea = new JTextArea();
        reportArea.setEditable(false);
        add(new JScrollPane(reportArea), BorderLayout.CENTER);

        JMenuBar menuBar = new JMenuBar();
        JMenu fileMenu = new JMenu("File");
        JMenuItem exitMenuItem = new JMenuItem("Exit");
        exitMenuItem.addActionListener(e -> System.exit(0));
        fileMenu.add(exitMenuItem);

        JMenu toolsMenu = new JMenu("Tools");
        JMenuItem processMenuItem = new JMenuItem("Process");
        processMenuItem.addActionListener(new ProcessAction());
        JMenuItem clearMenuItem = new JMenuItem("Clear");
        clearMenuItem.addActionListener(e -> clearFields());
        toolsMenu.add(processMenuItem);
        toolsMenu.add(clearMenuItem);

        menuBar.add(fileMenu);
        menuBar.add(toolsMenu);
        setJMenuBar(menuBar);
    }

    private void clearFields() {
        numberOfTicketsField.setText("");
        ticketPriceField.setText("");
        reportArea.setText("");
    }

    private class ProcessAction implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            String movieName = (String) movieComboBox.getSelectedItem();
            try {
                int numberOfTickets = Integer.parseInt(numberOfTicketsField.getText());
                double ticketPrice = Double.parseDouble(ticketPriceField.getText());

                MovieTicketData data = new MovieTicketData(movieName, numberOfTickets, ticketPrice);
                if (movieTickets.validateData(data)) {
                    double totalPrice = movieTickets.calculateTotalTicketPrice(numberOfTickets, ticketPrice);
                    String report = generateReport(movieName, ticketPrice, numberOfTickets, totalPrice);
                    reportArea.setText(report);
                    saveReport(report);
                }
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(null, "Please enter valid numbers for tickets and price.");
            }
        }
    }

    private String generateReport(String movieName, double ticketPrice, int numberOfTickets, double totalPrice) {
        return String.format(
                "MOVIE TICKET REPORT\nMOVIE NAME: %s\nMOVIE TICKET PRICE: R %.2f\nNUMBER OF TICKETS: %d\nTOTAL TICKET PRICE: R %.2f",
                movieName, ticketPrice, numberOfTickets, totalPrice);
    }

    private void saveReport(String report) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter("report.txt"))) {
            writer.write(report);
            JOptionPane.showMessageDialog(null, "Report saved to report.txt.");
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Error saving report.");
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new Question2().setVisible(true));
    }
}

// Unit tests
class MovieTicketsTest {
    @Test
    void calculateTotalTicketPrice_CalculatedSuccessfully() {
        MovieTickets movieTickets = new MovieTickets();
        int numberOfTickets = 3;
        double ticketPrice = 100.0;
        double expectedTotal = 342.0;
        assertEquals(expectedTotal, movieTickets.calculateTotalTicketPrice(numberOfTickets, ticketPrice), 0.01);
    }

    private void assertEquals(double expectedTotal, double calculateTotalTicketPrice, double delta) {
        
        throw new UnsupportedOperationException("Unimplemented method 'assertEquals'");
    }

    @Test
    void validateData_InvalidTicketPrice() {
        MovieTickets movieTickets = new MovieTickets();
        MovieTicketData invalidData = new MovieTicketData("Napoleon", 3, -100);
        assertFalse(movieTickets.validateData(invalidData));
    }

    private void assertFalse(boolean validateData) {
        
        throw new UnsupportedOperationException("Unimplemented method 'assertFalse'");
    }
}
