// File: App.java
// Package declaration
package prog6112.exam;

// Interface defining methods for movie ticket sales operations
interface IMovieTickets {
    int TotalMovieSales(int[] movieTicketSales);
    String TopMovie(String[] movies, int[] totalSales);
}

// MovieTickets class implementing the IMovieTickets interface
class MovieTickets implements IMovieTickets {
    // Calculate the total sales for a movie based on monthly sales
    @Override
    public int TotalMovieSales(int[] movieTicketSales) {
        int total = 0;
        for (int sale : movieTicketSales) {
            total += sale;
        }
        return total;
    }

    // Find the top-performing movie from an array of movie names and total sales
    @Override
    public String TopMovie(String[] movies, int[] totalSales) {
        int maxIndex = 0;
        for (int i = 1; i < totalSales.length; i++) {
            if (totalSales[i] > totalSales[maxIndex]) {
                maxIndex = i;
            }
        }
        return movies[maxIndex];
    }
}

// Main application for displaying the movie ticket sales report
public class App {
    // Greet method to maintain compatibility with existing code
    public String getGreeting() {
        return "Welcome to the Movie Ticket Sales Report Application!";
    }

    // Method to display the sales report
    public static void displaySalesReport(String[] movies, int[][] sales) {
        MovieTickets movieTickets = new MovieTickets();

        // Print sales report header
        System.out.println("MOVIE TICKET SALES REPORT - 2024");
        System.out.println("--------------------------------");
        System.out.printf("%-12s%8s%8s%8s\n", "MOVIE", "JAN", "FEB", "MAR");

        // Display monthly sales for each movie
        int[] totalSales = new int[movies.length];
        for (int i = 0; i < movies.length; i++) {
            System.out.printf("%-12s", movies[i]);
            for (int sale : sales[i]) {
                System.out.printf("%8d", sale);
            }
            System.out.println();
            
            // Calculate total sales for each movie
            totalSales[i] = movieTickets.TotalMovieSales(sales[i]);
            System.out.println("Total movie ticket sales for " + movies[i] + ": " + totalSales[i]);
        }

        // Find and display the top-performing movie
        String topMovie = movieTickets.TopMovie(movies, totalSales);
        System.out.println("\nTop performing movie: " + topMovie);
    }

    // Main method to run the application
    public static void main(String[] args) {
        App app = new App();
        System.out.println(app.getGreeting());

        // Define movies and their monthly sales for January, February, and March
        String[] movies = {"Napoleon", "Oppenheimer"};
        int[][] sales = {
            {3000, 1500, 1700},  // Napoleon sales for Jan, Feb, Mar
            {3500, 1200, 1600}   // Oppenheimer sales for Jan, Feb, Mar
        };

        // Display the sales report
        displaySalesReport(movies, sales);
    }
}

