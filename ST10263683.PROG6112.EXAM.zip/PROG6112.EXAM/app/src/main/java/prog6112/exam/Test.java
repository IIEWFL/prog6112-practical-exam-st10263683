package prog6112.exam;

public @interface Test {

}
